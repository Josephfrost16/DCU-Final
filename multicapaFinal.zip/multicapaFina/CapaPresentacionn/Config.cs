﻿using CapaNegocio.Aulas;
using CapaNegocio.Carreras;
using CapaNegocio.Edificios;
using CapaNegocio.Usuarios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacionn
{
    public partial class Config : Form
    {
        public Config()
        {
            InitializeComponent();
        }

        private void Config_Load(object sender, EventArgs e)
        {
            cargardatosAula();
            cargardatosCarreras();
            cargardatosEdificios();
            cargardatosUsuarios();

        }

        void cargardatosAula()
        {
            CN_Aulas aulas = new CN_Aulas();
            dataGridView1.DataSource = aulas.MostrarAulas();
        }

        void cargardatosCarreras()
        {
            CN_Carreras carreras = new CN_Carreras();
            dataGridView2.DataSource = carreras.MostrarCarreras();
        }

        void cargardatosEdificios()
        {
            CN_Edificios edificios = new CN_Edificios();
            dataGridView3.DataSource = edificios.MostrarEdificios();

        }

        void cargardatosUsuarios()
        {
            CN_Usuarios usuarios = new CN_Usuarios();
            dataGridView4.DataSource = usuarios.MostrarUsuario();
        }
    }
}
