﻿using CapaDatos.Visitantes;
using CapaNegocio.Aulas;
using CapaNegocio.Carreras;
using CapaNegocio.Edificios;
using CapaNegocio.Visitantes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacionn
{
    public partial class Registro : Form
    {

        byte[] imagenByte;
        CN_Edificios EdificiosCn = new CN_Edificios();
        CN_Aulas AulaCn = new CN_Aulas();
        CN_Visitantes visitantesCn = new CN_Visitantes();
        CN_Carreras carrera = new CN_Carreras();
        public Registro()
        {
            InitializeComponent();
            CargarDatos(ediText, EdificiosCn.MostrarEdificios(), "Edificio", "ID");
            CargarDatos(carrText, carrera.MostrarCarreras(), "Carrera", "ID");


        }

        private void Registro_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;



        }

        bool IsValidEmail(string email)
        {
            try
            {
                var mail = new System.Net.Mail.MailAddress(email);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Selecciona una imagen";
            openFileDialog1.Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.gif|Todos los archivos|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Obtén la ruta de la imagen seleccionada
                    string rutaImagen = openFileDialog1.FileName;

                    // Carga la imagen en un PictureBox u otro control según lo necesites
                    pictureBox1.Image = new System.Drawing.Bitmap(rutaImagen);

                    imagenByte = File.ReadAllBytes(rutaImagen);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar la imagen: " + ex.Message);
                }
            }

        }

        private void ediText_SelectedIndexChanged(object sender, EventArgs e)
        {

            CargarDatosAula(AulaCn.MostrarAulas(ediText.SelectedIndex + 1));
        }

        void CargarDatos(ComboBox a, DataTable b, string col, string val)
        {
            a.DataSource = b;
            a.DisplayMember = col;
            a.ValueMember = val;

        }

        void CargarDatosAula(DataTable b)
        {

            aulaText.ValueMember = "ID_Aula";
            aulaText.DisplayMember = "Aula";
            aulaText.DataSource = b;

        }

        private void AulaText_SelectedIndexChanged(object? sender, EventArgs e)
        {

        }

        private void ediText_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void ediText_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                if (IsValidEmail(corText.Text))
                {
                    string nombre = nomText.Text;
                    string apellido = apeText.Text;
                    int carrera = (int)carrText.SelectedValue;
                    string correo = corText.Text;
                    int edificio = (int)ediText.SelectedValue;
                    DateTime entrada = entradaDate.Value;
                    DateTime salida = salidaDate.Value;
                    string motivo = textBox8.Text;
                    int aula = (int)aulaText.SelectedValue;

                    visitantesCn.InsertarVisitantes(nombre, apellido, carrera, correo, edificio, entrada, salida, motivo, imagenByte, aula);

                    MessageBox.Show("Los datos se insertaron con exito", "Advice", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    MessageBox.Show("Email no Valido", "Advice", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrio un error inesperado", "Advice", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void apeText_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
