﻿namespace CapaPresentacionn
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menubar = new FlowLayoutPanel();
            panel2 = new Panel();
            button1 = new Button();
            panel3 = new Panel();
            RegisterButton = new Button();
            panel4 = new Panel();
            ConsultaButton = new Button();
            configContainer = new FlowLayoutPanel();
            panel6 = new Panel();
            configButton = new Button();
            panel7 = new Panel();
            button6 = new Button();
            panel8 = new Panel();
            button7 = new Button();
            configTransition = new System.Windows.Forms.Timer(components);
            SideMenuBar = new System.Windows.Forms.Timer(components);
            pictureBox1 = new PictureBox();
            label1 = new Label();
            nightControlBox1 = new ReaLTaiizor.Controls.NightControlBox();
            panel1 = new Panel();
            menubar.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            configContainer.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // menubar
            // 
            menubar.BackColor = Color.FromArgb(23, 24, 31);
            menubar.Controls.Add(panel2);
            menubar.Controls.Add(panel3);
            menubar.Controls.Add(panel4);
            menubar.Controls.Add(configContainer);
            menubar.Dock = DockStyle.Left;
            menubar.Location = new Point(0, 41);
            menubar.Name = "menubar";
            menubar.Padding = new Padding(0, 30, 0, 0);
            menubar.Size = new Size(195, 594);
            menubar.TabIndex = 1;
            menubar.Paint += menubar_Paint;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Cursor = Cursors.Hand;
            panel2.Location = new Point(3, 33);
            panel2.Name = "panel2";
            panel2.Size = new Size(205, 43);
            panel2.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(23, 24, 31);
            button1.Font = new Font("Segoe UI", 9.75F);
            button1.ForeColor = Color.White;
            button1.Image = Properties.Resources.home__3_;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(-15, -12);
            button1.Name = "button1";
            button1.Padding = new Padding(25, 0, 0, 0);
            button1.Size = new Size(233, 67);
            button1.TabIndex = 3;
            button1.Text = "         Inicio";
            button1.TextAlign = ContentAlignment.MiddleLeft;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            button1.MouseEnter += button1_MouseEnter;
            button1.MouseLeave += button1_MouseLeave;
            // 
            // panel3
            // 
            panel3.Controls.Add(RegisterButton);
            panel3.Cursor = Cursors.Hand;
            panel3.Location = new Point(3, 82);
            panel3.Name = "panel3";
            panel3.Size = new Size(205, 43);
            panel3.TabIndex = 4;
            // 
            // RegisterButton
            // 
            RegisterButton.BackColor = Color.FromArgb(23, 24, 31);
            RegisterButton.Font = new Font("Segoe UI", 9.75F);
            RegisterButton.ForeColor = Color.White;
            RegisterButton.Image = Properties.Resources.add__1_;
            RegisterButton.ImageAlign = ContentAlignment.MiddleLeft;
            RegisterButton.Location = new Point(-15, -12);
            RegisterButton.Name = "RegisterButton";
            RegisterButton.Padding = new Padding(25, 0, 0, 0);
            RegisterButton.Size = new Size(233, 67);
            RegisterButton.TabIndex = 3;
            RegisterButton.Text = "         Registrar Visita";
            RegisterButton.TextAlign = ContentAlignment.MiddleLeft;
            RegisterButton.UseVisualStyleBackColor = false;
            RegisterButton.Click += RegisterButton_Click;
            RegisterButton.MouseEnter += button2_MouseEnter;
            RegisterButton.MouseLeave += button2_MouseLeave;
            // 
            // panel4
            // 
            panel4.Controls.Add(ConsultaButton);
            panel4.Cursor = Cursors.Hand;
            panel4.Location = new Point(3, 131);
            panel4.Name = "panel4";
            panel4.Size = new Size(205, 43);
            panel4.TabIndex = 4;
            // 
            // ConsultaButton
            // 
            ConsultaButton.BackColor = Color.FromArgb(23, 24, 31);
            ConsultaButton.Font = new Font("Segoe UI", 9.75F);
            ConsultaButton.ForeColor = Color.White;
            ConsultaButton.Image = Properties.Resources.select;
            ConsultaButton.ImageAlign = ContentAlignment.MiddleLeft;
            ConsultaButton.Location = new Point(-15, -12);
            ConsultaButton.Name = "ConsultaButton";
            ConsultaButton.Padding = new Padding(25, 0, 0, 0);
            ConsultaButton.Size = new Size(233, 67);
            ConsultaButton.TabIndex = 3;
            ConsultaButton.Text = "         Consultar Visitas";
            ConsultaButton.TextAlign = ContentAlignment.MiddleLeft;
            ConsultaButton.UseVisualStyleBackColor = false;
            ConsultaButton.Click += ConsultaButton_Click;
            ConsultaButton.MouseEnter += button3_MouseEnter;
            ConsultaButton.MouseLeave += button3_MouseLeave;
            // 
            // configContainer
            // 
            configContainer.BackColor = Color.FromArgb(32, 33, 36);
            configContainer.Controls.Add(panel6);
            configContainer.Controls.Add(panel7);
            configContainer.Controls.Add(panel8);
            configContainer.Cursor = Cursors.Hand;
            configContainer.Location = new Point(3, 180);
            configContainer.Name = "configContainer";
            configContainer.Size = new Size(205, 43);
            configContainer.TabIndex = 5;
            // 
            // panel6
            // 
            panel6.Controls.Add(configButton);
            panel6.Location = new Point(0, 0);
            panel6.Margin = new Padding(0);
            panel6.Name = "panel6";
            panel6.Size = new Size(205, 43);
            panel6.TabIndex = 5;
            // 
            // configButton
            // 
            configButton.BackColor = Color.FromArgb(23, 24, 31);
            configButton.Font = new Font("Segoe UI", 9.75F);
            configButton.ForeColor = Color.White;
            configButton.Image = (Image)resources.GetObject("configButton.Image");
            configButton.ImageAlign = ContentAlignment.MiddleLeft;
            configButton.Location = new Point(-15, -12);
            configButton.Name = "configButton";
            configButton.Padding = new Padding(25, 0, 0, 0);
            configButton.Size = new Size(233, 67);
            configButton.TabIndex = 3;
            configButton.Text = "         Configuracion";
            configButton.TextAlign = ContentAlignment.MiddleLeft;
            configButton.UseVisualStyleBackColor = false;
            configButton.Click += button5_Click;
            configButton.MouseEnter += button5_MouseEnter;
            configButton.MouseLeave += button5_MouseLeave;
            // 
            // panel7
            // 
            panel7.Controls.Add(button6);
            panel7.Location = new Point(0, 43);
            panel7.Margin = new Padding(0);
            panel7.Name = "panel7";
            panel7.Size = new Size(205, 43);
            panel7.TabIndex = 5;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(32, 33, 36);
            button6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Image = Properties.Resources.black_circle;
            button6.ImageAlign = ContentAlignment.MiddleLeft;
            button6.Location = new Point(-15, -12);
            button6.Name = "button6";
            button6.Padding = new Padding(25, 0, 0, 0);
            button6.Size = new Size(233, 67);
            button6.TabIndex = 3;
            button6.Text = "         Editar Informacion";
            button6.TextAlign = ContentAlignment.MiddleLeft;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // panel8
            // 
            panel8.Controls.Add(button7);
            panel8.Location = new Point(0, 86);
            panel8.Margin = new Padding(0);
            panel8.Name = "panel8";
            panel8.Size = new Size(205, 43);
            panel8.TabIndex = 6;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(32, 33, 36);
            button7.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.White;
            button7.Image = Properties.Resources.power_off;
            button7.ImageAlign = ContentAlignment.MiddleLeft;
            button7.Location = new Point(-15, -12);
            button7.Name = "button7";
            button7.Padding = new Padding(25, 0, 0, 0);
            button7.Size = new Size(233, 67);
            button7.TabIndex = 3;
            button7.Text = "         Cerrar Sesion";
            button7.TextAlign = ContentAlignment.MiddleLeft;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // configTransition
            // 
            configTransition.Interval = 10;
            configTransition.Tick += configTransition_Tick;
            // 
            // SideMenuBar
            // 
            SideMenuBar.Interval = 10;
            SideMenuBar.Tick += SideMenuBar_Tick;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.menu__1_;
            pictureBox1.Location = new Point(10, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(40, 14);
            label1.Name = "label1";
            label1.Size = new Size(247, 15);
            label1.TabIndex = 2;
            label1.Text = "PROGRAMACION 2 | REGISTRO DE VISITAS";
            // 
            // nightControlBox1
            // 
            nightControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            nightControlBox1.BackColor = Color.Transparent;
            nightControlBox1.CloseHoverColor = Color.FromArgb(199, 80, 80);
            nightControlBox1.CloseHoverForeColor = Color.White;
            nightControlBox1.DefaultLocation = true;
            nightControlBox1.DisableMaximizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.DisableMinimizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.EnableCloseColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMaximizeButton = true;
            nightControlBox1.EnableMaximizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMinimizeButton = true;
            nightControlBox1.EnableMinimizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.Location = new Point(869, 0);
            nightControlBox1.MaximizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MaximizeHoverForeColor = Color.White;
            nightControlBox1.MinimizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MinimizeHoverForeColor = Color.White;
            nightControlBox1.Name = "nightControlBox1";
            nightControlBox1.Size = new Size(139, 31);
            nightControlBox1.TabIndex = 3;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(20, 20, 111);
            panel1.Controls.Add(nightControlBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1008, 41);
            panel1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1008, 635);
            Controls.Add(menubar);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            IsMdiContainer = true;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            menubar.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            configContainer.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private FlowLayoutPanel menubar;
        private Panel panel2;
        private Button button1;
        private Panel panel3;
        private Button RegisterButton;
        private Panel panel4;
        private Button ConsultaButton;
        private Panel panel5;
        private Button button4;
        private FlowLayoutPanel configContainer;
        private Panel panel6;
        private Button configButton;
        private Panel panel7;
        private Button button6;
        private Panel panel8;
        private Button button7;
        private System.Windows.Forms.Timer configTransition;
        private System.Windows.Forms.Timer SideMenuBar;
        private PictureBox pictureBox1;
        private Label label1;
        private ReaLTaiizor.Controls.NightControlBox nightControlBox1;
        private Panel panel1;
    }
}
