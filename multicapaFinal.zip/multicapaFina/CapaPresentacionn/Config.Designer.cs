﻿namespace CapaPresentacionn
{
    partial class Config
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Config));
            label1 = new Label();
            panel1 = new Panel();
            button10 = new Button();
            button3 = new Button();
            button2 = new Button();
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            panel2 = new Panel();
            button11 = new Button();
            button4 = new Button();
            button5 = new Button();
            label2 = new Label();
            dataGridView3 = new DataGridView();
            panel3 = new Panel();
            button12 = new Button();
            button6 = new Button();
            button7 = new Button();
            label3 = new Label();
            dataGridView4 = new DataGridView();
            label4 = new Label();
            carrText = new ComboBox();
            label5 = new Label();
            apeText = new TextBox();
            label6 = new Label();
            nomText = new TextBox();
            label7 = new Label();
            textBox1 = new TextBox();
            label8 = new Label();
            button1 = new Button();
            panel4 = new Panel();
            button8 = new Button();
            button9 = new Button();
            textBox2 = new TextBox();
            label9 = new Label();
            label10 = new Label();
            dateTimePicker1 = new DateTimePicker();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = Color.FromArgb(20, 20, 111);
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 20);
            label1.Name = "label1";
            label1.Padding = new Padding(3, 1, 3, 1);
            label1.Size = new Size(215, 25);
            label1.TabIndex = 1;
            label1.Text = "Edificios";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(20, 20, 111);
            panel1.Controls.Add(button10);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Location = new Point(226, 20);
            panel1.Name = "panel1";
            panel1.Size = new Size(30, 167);
            panel1.TabIndex = 2;
            // 
            // button10
            // 
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Image = (Image)resources.GetObject("button10.Image");
            button10.Location = new Point(3, 87);
            button10.Name = "button10";
            button10.Size = new Size(25, 23);
            button10.TabIndex = 2;
            button10.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.Location = new Point(2, 57);
            button3.Name = "button3";
            button3.Size = new Size(25, 23);
            button3.TabIndex = 1;
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.Location = new Point(4, 28);
            button2.Name = "button2";
            button2.Size = new Size(25, 23);
            button2.TabIndex = 0;
            button2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 43);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Size = new Size(215, 144);
            dataGridView1.TabIndex = 3;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(279, 43);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersVisible = false;
            dataGridView2.Size = new Size(215, 144);
            dataGridView2.TabIndex = 6;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(20, 20, 111);
            panel2.Controls.Add(button11);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button5);
            panel2.Location = new Point(493, 20);
            panel2.Name = "panel2";
            panel2.Size = new Size(30, 167);
            panel2.TabIndex = 5;
            // 
            // button11
            // 
            button11.FlatAppearance.BorderSize = 0;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Image = (Image)resources.GetObject("button11.Image");
            button11.Location = new Point(0, 87);
            button11.Name = "button11";
            button11.Size = new Size(25, 23);
            button11.TabIndex = 3;
            button11.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.Location = new Point(1, 57);
            button4.Name = "button4";
            button4.Size = new Size(25, 23);
            button4.TabIndex = 3;
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(2, 28);
            button5.Name = "button5";
            button5.Size = new Size(25, 23);
            button5.TabIndex = 2;
            button5.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.BackColor = Color.FromArgb(20, 20, 111);
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(279, 20);
            label2.Name = "label2";
            label2.Padding = new Padding(3, 1, 3, 1);
            label2.Size = new Size(215, 25);
            label2.TabIndex = 4;
            label2.Text = "Aulas";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(543, 43);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersVisible = false;
            dataGridView3.Size = new Size(215, 144);
            dataGridView3.TabIndex = 9;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(20, 20, 111);
            panel3.Controls.Add(button12);
            panel3.Controls.Add(button6);
            panel3.Controls.Add(button7);
            panel3.Location = new Point(757, 20);
            panel3.Name = "panel3";
            panel3.Size = new Size(30, 167);
            panel3.TabIndex = 8;
            // 
            // button12
            // 
            button12.FlatAppearance.BorderSize = 0;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Image = (Image)resources.GetObject("button12.Image");
            button12.Location = new Point(3, 89);
            button12.Name = "button12";
            button12.Size = new Size(25, 23);
            button12.TabIndex = 4;
            button12.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Image = (Image)resources.GetObject("button6.Image");
            button6.Location = new Point(2, 57);
            button6.Name = "button6";
            button6.Size = new Size(25, 23);
            button6.TabIndex = 5;
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(4, 28);
            button7.Name = "button7";
            button7.Size = new Size(25, 23);
            button7.TabIndex = 4;
            button7.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.BackColor = Color.FromArgb(20, 20, 111);
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(543, 20);
            label3.Name = "label3";
            label3.Padding = new Padding(3, 1, 3, 1);
            label3.Size = new Size(215, 25);
            label3.TabIndex = 7;
            label3.Text = "Carreras";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(41, 240);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersVisible = false;
            dataGridView4.Size = new Size(482, 341);
            dataGridView4.TabIndex = 10;
            // 
            // label4
            // 
            label4.BackColor = Color.FromArgb(20, 20, 111);
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(12, 215);
            label4.Name = "label4";
            label4.Padding = new Padding(3, 1, 3, 1);
            label4.Size = new Size(511, 25);
            label4.TabIndex = 11;
            label4.Text = "Edificios";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // carrText
            // 
            carrText.BackColor = Color.WhiteSmoke;
            carrText.Font = new Font("Segoe UI", 12F);
            carrText.FormattingEnabled = true;
            carrText.Location = new Point(674, 500);
            carrText.Name = "carrText";
            carrText.Size = new Size(112, 29);
            carrText.TabIndex = 26;
            // 
            // label5
            // 
            label5.BackColor = Color.FromArgb(20, 20, 111);
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(674, 476);
            label5.Name = "label5";
            label5.Padding = new Padding(3, 1, 3, 1);
            label5.Size = new Size(112, 25);
            label5.TabIndex = 25;
            label5.Text = "Rol";
            label5.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // apeText
            // 
            apeText.BackColor = Color.FromArgb(13, 13, 74);
            apeText.BorderStyle = BorderStyle.FixedSingle;
            apeText.Font = new Font("Segoe UI", 12F);
            apeText.ForeColor = Color.White;
            apeText.Location = new Point(547, 364);
            apeText.Name = "apeText";
            apeText.Size = new Size(239, 29);
            apeText.TabIndex = 24;
            // 
            // label6
            // 
            label6.BackColor = Color.FromArgb(20, 20, 111);
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(547, 340);
            label6.Name = "label6";
            label6.Padding = new Padding(3, 1, 3, 1);
            label6.Size = new Size(239, 25);
            label6.TabIndex = 23;
            label6.Text = "Usuario";
            label6.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // nomText
            // 
            nomText.BackColor = Color.FromArgb(13, 13, 74);
            nomText.BorderStyle = BorderStyle.FixedSingle;
            nomText.Font = new Font("Segoe UI", 12F);
            nomText.ForeColor = Color.White;
            nomText.Location = new Point(547, 239);
            nomText.Name = "nomText";
            nomText.Size = new Size(239, 29);
            nomText.TabIndex = 22;
            // 
            // label7
            // 
            label7.BackColor = Color.FromArgb(20, 20, 111);
            label7.BorderStyle = BorderStyle.FixedSingle;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(547, 215);
            label7.Name = "label7";
            label7.Padding = new Padding(3, 1, 3, 1);
            label7.Size = new Size(239, 25);
            label7.TabIndex = 21;
            label7.Text = "Nombre";
            label7.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(13, 13, 74);
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Segoe UI", 12F);
            textBox1.ForeColor = Color.White;
            textBox1.Location = new Point(547, 301);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(239, 29);
            textBox1.TabIndex = 28;
            // 
            // label8
            // 
            label8.BackColor = Color.FromArgb(20, 20, 111);
            label8.BorderStyle = BorderStyle.FixedSingle;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(547, 277);
            label8.Name = "label8";
            label8.Padding = new Padding(3, 1, 3, 1);
            label8.Size = new Size(239, 25);
            label8.TabIndex = 27;
            label8.Text = "Apellido";
            label8.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(20, 20, 111);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(547, 541);
            button1.Name = "button1";
            button1.Size = new Size(239, 37);
            button1.TabIndex = 29;
            button1.Text = "Agregar";
            button1.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(20, 20, 111);
            panel4.Controls.Add(button8);
            panel4.Controls.Add(button9);
            panel4.Location = new Point(12, 239);
            panel4.Name = "panel4";
            panel4.Size = new Size(30, 342);
            panel4.TabIndex = 3;
            // 
            // button8
            // 
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Image = (Image)resources.GetObject("button8.Image");
            button8.Location = new Point(2, 40);
            button8.Name = "button8";
            button8.Size = new Size(25, 23);
            button8.TabIndex = 35;
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Image = (Image)resources.GetObject("button9.Image");
            button9.Location = new Point(2, 11);
            button9.Name = "button9";
            button9.Size = new Size(25, 23);
            button9.TabIndex = 34;
            button9.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(13, 13, 74);
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Segoe UI", 12F);
            textBox2.ForeColor = Color.White;
            textBox2.Location = new Point(547, 432);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(239, 29);
            textBox2.TabIndex = 31;
            // 
            // label9
            // 
            label9.BackColor = Color.FromArgb(20, 20, 111);
            label9.BorderStyle = BorderStyle.FixedSingle;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(547, 408);
            label9.Name = "label9";
            label9.Padding = new Padding(3, 1, 3, 1);
            label9.Size = new Size(239, 25);
            label9.TabIndex = 30;
            label9.Text = "Contraseña";
            label9.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            label10.BackColor = Color.FromArgb(20, 20, 111);
            label10.BorderStyle = BorderStyle.FixedSingle;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(547, 476);
            label10.Name = "label10";
            label10.Padding = new Padding(3, 1, 3, 1);
            label10.Size = new Size(116, 25);
            label10.TabIndex = 32;
            label10.Text = "Cumpleaños";
            label10.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(547, 500);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(116, 23);
            dateTimePicker1.TabIndex = 33;
            // 
            // Config
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(804, 593);
            Controls.Add(dateTimePicker1);
            Controls.Add(label10);
            Controls.Add(textBox2);
            Controls.Add(label9);
            Controls.Add(panel4);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label8);
            Controls.Add(carrText);
            Controls.Add(label5);
            Controls.Add(apeText);
            Controls.Add(label6);
            Controls.Add(nomText);
            Controls.Add(label7);
            Controls.Add(label4);
            Controls.Add(dataGridView4);
            Controls.Add(dataGridView3);
            Controls.Add(panel3);
            Controls.Add(label3);
            Controls.Add(dataGridView2);
            Controls.Add(panel2);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Controls.Add(panel1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Config";
            Text = "Config";
            Load += Config_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Panel panel2;
        private Label label2;
        private DataGridView dataGridView3;
        private Panel panel3;
        private Label label3;
        private DataGridView dataGridView4;
        private Label label4;
        private ComboBox carrText;
        private Label label5;
        private TextBox apeText;
        private Label label6;
        private TextBox nomText;
        private Label label7;
        private TextBox textBox1;
        private Label label8;
        private Button button1;
        private Panel panel4;
        private TextBox textBox2;
        private Label label9;
        private Label label10;
        private DateTimePicker dateTimePicker1;
        private Button button3;
        private Button button2;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
    }
}