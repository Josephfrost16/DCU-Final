﻿using CapaNegocio.Visitantes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CapaPresentacionn
{
    public partial class Consulta : Form
    {
        public Consulta()
        {
            InitializeComponent();
            cargardatos();
        }

        bool menuHide = true;


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            hide_submenu.Start();
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            hide_submenu.Start();
        }

        void pintarButton(System.Windows.Forms.Button a, int r, int g, int b)
        {
            a.BackColor = Color.FromArgb(r, g, b);
        }

        private void hide_submenu_Tick(object sender, EventArgs e)
        {
            if (menuHide == false)
            {
                menubar.Width += 10;
                if (menubar.Width >= 85)
                {
                    hide_submenu.Stop();
                    menuHide = true;

                }
            }
            else
            {
                menubar.Width -= 10;
                if (menubar.Width <= 44)
                {
                    hide_submenu.Stop();
                    menuHide = false;
                }
            }
        }


        private void cargardatos()
        {
            CN_Visitantes _Visitantes = new CN_Visitantes();
            dataGridView1.DataSource = _Visitantes.MostrarVisitantes();

            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 20, 111);
            dataGridView1.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 20, 111);
            dataGridView1.DefaultCellStyle.BackColor = Color.White;
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            dataGridView1.RowHeadersVisible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            pintarButton(button1, 20, 20, 111);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            pintarButton(button2, 20, 20, 111);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            pintarButton(button1, 23, 24, 31);
        }

        private void button2_Leave(object sender, EventArgs e)
        {

        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            pintarButton(button2, 23, 24, 31);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Consulta_Load(object sender, EventArgs e)
        {
            cargardatos();
        }

        private void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex == -1 && e.ColumnIndex >= 0)
            {
                // Pintar el fondo del encabezado de la columna con el color deseado
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(20, 20, 111)), e.CellBounds);

                // Dibujar el texto del encabezado de la columna
                if (e.Value != null)
                {
                    StringFormat sf = new StringFormat();
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;

                    Font headerFont = new Font(e.CellStyle.Font, FontStyle.Bold);
                    e.Graphics.DrawString(e.Value.ToString(), headerFont, Brushes.White, e.CellBounds, sf);
                }

                // Evitar la pintura predeterminada
                e.Handled = true;
            }
        }
    }
}
