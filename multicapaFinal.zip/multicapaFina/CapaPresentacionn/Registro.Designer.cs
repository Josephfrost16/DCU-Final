﻿namespace CapaPresentacionn
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            nomText = new TextBox();
            apeText = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            textBox8 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            openFileDialog1 = new OpenFileDialog();
            carrText = new ComboBox();
            ediText = new ComboBox();
            aulaText = new ComboBox();
            entradaDate = new DateTimePicker();
            salidaDate = new DateTimePicker();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            button1 = new Button();
            button2 = new Button();
            corText = new MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = Color.FromArgb(20, 20, 111);
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 65);
            label1.Name = "label1";
            label1.Padding = new Padding(3, 1, 3, 1);
            label1.Size = new Size(380, 25);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // nomText
            // 
            nomText.BackColor = Color.FromArgb(13, 13, 74);
            nomText.BorderStyle = BorderStyle.FixedSingle;
            nomText.Font = new Font("Segoe UI", 12F);
            nomText.ForeColor = Color.White;
            nomText.Location = new Point(12, 89);
            nomText.Name = "nomText";
            nomText.Size = new Size(380, 29);
            nomText.TabIndex = 2;
            // 
            // apeText
            // 
            apeText.BackColor = Color.FromArgb(13, 13, 74);
            apeText.BorderStyle = BorderStyle.FixedSingle;
            apeText.Font = new Font("Segoe UI", 12F);
            apeText.ForeColor = Color.White;
            apeText.Location = new Point(12, 159);
            apeText.Name = "apeText";
            apeText.Size = new Size(380, 29);
            apeText.TabIndex = 4;
            apeText.TextChanged += apeText_TextChanged;
            // 
            // label3
            // 
            label3.BackColor = Color.FromArgb(20, 20, 111);
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(12, 135);
            label3.Name = "label3";
            label3.Padding = new Padding(3, 1, 3, 1);
            label3.Size = new Size(380, 25);
            label3.TabIndex = 3;
            label3.Text = "Apellido";
            label3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            label4.BackColor = Color.FromArgb(20, 20, 111);
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(12, 204);
            label4.Name = "label4";
            label4.Padding = new Padding(3, 1, 3, 1);
            label4.Size = new Size(380, 25);
            label4.TabIndex = 5;
            label4.Text = "Carrera";
            label4.TextAlign = ContentAlignment.MiddleLeft;
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.BackColor = Color.FromArgb(20, 20, 111);
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(12, 274);
            label5.Name = "label5";
            label5.Padding = new Padding(3, 1, 3, 1);
            label5.Size = new Size(380, 25);
            label5.TabIndex = 7;
            label5.Text = "Correo";
            label5.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            label6.BackColor = Color.FromArgb(20, 20, 111);
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(12, 346);
            label6.Name = "label6";
            label6.Padding = new Padding(3, 1, 3, 1);
            label6.Size = new Size(380, 25);
            label6.TabIndex = 9;
            label6.Text = "Edificio";
            label6.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            label7.BackColor = Color.FromArgb(20, 20, 111);
            label7.BorderStyle = BorderStyle.FixedSingle;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(12, 412);
            label7.Name = "label7";
            label7.Padding = new Padding(3, 1, 3, 1);
            label7.Size = new Size(182, 25);
            label7.TabIndex = 11;
            label7.Text = "Hora Entrada";
            label7.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            label8.BackColor = Color.FromArgb(20, 20, 111);
            label8.BorderStyle = BorderStyle.FixedSingle;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(208, 412);
            label8.Name = "label8";
            label8.Padding = new Padding(3, 1, 3, 1);
            label8.Size = new Size(184, 25);
            label8.TabIndex = 13;
            label8.Text = "Hora Salida";
            label8.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            label9.BackColor = Color.FromArgb(20, 20, 111);
            label9.BorderStyle = BorderStyle.FixedSingle;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(12, 484);
            label9.Name = "label9";
            label9.Padding = new Padding(3, 1, 3, 1);
            label9.Size = new Size(380, 25);
            label9.TabIndex = 15;
            label9.Text = "Aula";
            label9.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.WhiteSmoke;
            textBox8.BorderStyle = BorderStyle.FixedSingle;
            textBox8.Font = new Font("Segoe UI", 12F);
            textBox8.Location = new Point(414, 374);
            textBox8.Multiline = true;
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(387, 164);
            textBox8.TabIndex = 18;
            // 
            // label10
            // 
            label10.BackColor = Color.FromArgb(20, 20, 111);
            label10.BorderStyle = BorderStyle.FixedSingle;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(414, 350);
            label10.Name = "label10";
            label10.Padding = new Padding(3, 1, 3, 1);
            label10.Size = new Size(387, 25);
            label10.TabIndex = 17;
            label10.Text = "Motivo";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            label11.BackColor = Color.FromArgb(20, 20, 111);
            label11.BorderStyle = BorderStyle.FixedSingle;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(414, 65);
            label11.Name = "label11";
            label11.Padding = new Padding(3, 1, 3, 1);
            label11.Size = new Size(387, 25);
            label11.TabIndex = 19;
            label11.Text = "Foto";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // carrText
            // 
            carrText.BackColor = Color.WhiteSmoke;
            carrText.Font = new Font("Segoe UI", 12F);
            carrText.FormattingEnabled = true;
            carrText.Location = new Point(12, 229);
            carrText.Name = "carrText";
            carrText.Size = new Size(380, 29);
            carrText.TabIndex = 20;
            // 
            // ediText
            // 
            ediText.BackColor = Color.WhiteSmoke;
            ediText.Font = new Font("Segoe UI", 12F);
            ediText.FormattingEnabled = true;
            ediText.Location = new Point(12, 371);
            ediText.Name = "ediText";
            ediText.Size = new Size(380, 29);
            ediText.TabIndex = 21;
            ediText.SelectedIndexChanged += ediText_SelectedIndexChanged;
            ediText.SelectedValueChanged += ediText_SelectedValueChanged;
            ediText.TextChanged += ediText_TextChanged;
            // 
            // aulaText
            // 
            aulaText.BackColor = Color.WhiteSmoke;
            aulaText.Font = new Font("Segoe UI", 12F);
            aulaText.FormattingEnabled = true;
            aulaText.Location = new Point(12, 509);
            aulaText.Name = "aulaText";
            aulaText.Size = new Size(380, 29);
            aulaText.TabIndex = 22;
            // 
            // entradaDate
            // 
            entradaDate.CalendarMonthBackground = Color.WhiteSmoke;
            entradaDate.Location = new Point(12, 437);
            entradaDate.Name = "entradaDate";
            entradaDate.Size = new Size(182, 23);
            entradaDate.TabIndex = 23;
            // 
            // salidaDate
            // 
            salidaDate.CalendarMonthBackground = Color.WhiteSmoke;
            salidaDate.Location = new Point(209, 436);
            salidaDate.Name = "salidaDate";
            salidaDate.Size = new Size(183, 23);
            salidaDate.TabIndex = 24;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Control;
            pictureBox1.Location = new Point(414, 89);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(387, 210);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 25;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label2
            // 
            label2.BackColor = Color.FromArgb(23, 24, 31);
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(0, 0);
            label2.Margin = new Padding(0);
            label2.Name = "label2";
            label2.Size = new Size(823, 52);
            label2.TabIndex = 26;
            label2.Text = "Registrar Visita";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            button1.Location = new Point(414, 298);
            button1.Name = "button1";
            button1.Size = new Size(387, 29);
            button1.TabIndex = 27;
            button1.Text = "Subir Imagen";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(20, 20, 111);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(12, 549);
            button2.Name = "button2";
            button2.Size = new Size(789, 34);
            button2.TabIndex = 28;
            button2.Text = "Registrar Visita";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // corText
            // 
            corText.BackColor = Color.FromArgb(13, 13, 74);
            corText.BorderStyle = BorderStyle.FixedSingle;
            corText.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            corText.ForeColor = Color.White;
            corText.Location = new Point(12, 298);
            corText.Name = "corText";
            corText.Size = new Size(380, 29);
            corText.TabIndex = 29;
            // 
            // Registro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(823, 594);
            Controls.Add(corText);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(salidaDate);
            Controls.Add(entradaDate);
            Controls.Add(aulaText);
            Controls.Add(ediText);
            Controls.Add(carrText);
            Controls.Add(label11);
            Controls.Add(textBox8);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(apeText);
            Controls.Add(label3);
            Controls.Add(nomText);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Registro";
            Text = "Registrar";
            Load += Registro_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox nomText;
        private TextBox apeText;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textBox8;
        private Label label10;
        private Label label11;
        private OpenFileDialog openFileDialog1;
        private ComboBox carrText;
        private ComboBox ediText;
        private ComboBox aulaText;
        private DateTimePicker entradaDate;
        private DateTimePicker salidaDate;
        private PictureBox pictureBox1;
        private Label label2;
        private Button button1;
        private Button button2;
        private MaskedTextBox corText;
    }
}