﻿using CapaNegocio.Usuarios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacionn
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

         
                CN_Usuarios usuarios = new CN_Usuarios();
                usuarios.InsertarUsuarios(NomTxt.Text,ApeTxt.Text,dateTimePicker1.Value,1,UserTxT.Text,PasTxT2.Text);
          
            this.Hide();
            Logincs login = new Logincs();
            login.ShowDialog();
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
