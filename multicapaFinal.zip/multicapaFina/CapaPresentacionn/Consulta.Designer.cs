﻿namespace CapaPresentacionn
{
    partial class Consulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Consulta));
            label2 = new Label();
            menubar = new FlowLayoutPanel();
            panel2 = new Panel();
            button1 = new Button();
            panel1 = new Panel();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            hide_submenu = new System.Windows.Forms.Timer(components);
            dataGridView1 = new DataGridView();
            panel3 = new Panel();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox1 = new TextBox();
            pictureBox2 = new PictureBox();
            menubar.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoEllipsis = true;
            label2.BackColor = Color.FromArgb(23, 24, 31);
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(0, 0);
            label2.Margin = new Padding(0);
            label2.Name = "label2";
            label2.Size = new Size(804, 52);
            label2.TabIndex = 27;
            label2.Text = "Consultar Visitas";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // menubar
            // 
            menubar.BackColor = Color.FromArgb(13, 13, 74);
            menubar.Controls.Add(panel2);
            menubar.Controls.Add(panel1);
            menubar.Controls.Add(pictureBox1);
            menubar.Dock = DockStyle.Right;
            menubar.FlowDirection = FlowDirection.RightToLeft;
            menubar.Location = new Point(719, 0);
            menubar.Margin = new Padding(0);
            menubar.Name = "menubar";
            menubar.Padding = new Padding(0, 60, 0, 0);
            menubar.Size = new Size(85, 594);
            menubar.TabIndex = 29;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Cursor = Cursors.Hand;
            panel2.Location = new Point(-150, 60);
            panel2.Margin = new Padding(0);
            panel2.Name = "panel2";
            panel2.Size = new Size(235, 43);
            panel2.TabIndex = 30;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(13, 13, 74);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 9.75F);
            button1.ForeColor = Color.White;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleRight;
            button1.Location = new Point(-8, -12);
            button1.Margin = new Padding(0);
            button1.Name = "button1";
            button1.Padding = new Padding(0, 0, 9, 0);
            button1.Size = new Size(246, 67);
            button1.TabIndex = 3;
            button1.Text = "Editar ";
            button1.TextAlign = ContentAlignment.MiddleRight;
            button1.TextImageRelation = TextImageRelation.TextBeforeImage;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            button1.MouseEnter += button1_MouseEnter;
            button1.MouseLeave += button1_MouseLeave;
            // 
            // panel1
            // 
            panel1.Controls.Add(button2);
            panel1.Cursor = Cursors.Hand;
            panel1.Location = new Point(-150, 103);
            panel1.Margin = new Padding(0);
            panel1.Name = "panel1";
            panel1.Size = new Size(235, 43);
            panel1.TabIndex = 31;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(13, 13, 74);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 9.75F);
            button2.ForeColor = Color.White;
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleRight;
            button2.Location = new Point(-8, -12);
            button2.Margin = new Padding(0);
            button2.Name = "button2";
            button2.Padding = new Padding(0, 0, 9, 0);
            button2.Size = new Size(246, 67);
            button2.TabIndex = 3;
            button2.Text = "Borrar ";
            button2.TextAlign = ContentAlignment.MiddleRight;
            button2.TextImageRelation = TextImageRelation.TextBeforeImage;
            button2.UseVisualStyleBackColor = false;
            button2.Leave += button2_Leave;
            button2.MouseEnter += button2_MouseEnter;
            button2.MouseLeave += button2_MouseLeave;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.BackColor = Color.FromArgb(13, 13, 74);
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.pencil1;
            pictureBox1.Location = new Point(58, 549);
            pictureBox1.Margin = new Padding(3, 403, 3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            pictureBox1.MouseClick += pictureBox1_MouseClick;
            // 
            // hide_submenu
            // 
            hide_submenu.Interval = 10;
            hide_submenu.Tick += hide_submenu_Tick;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.Gainsboro;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 55);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(915, 488);
            dataGridView1.TabIndex = 30;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            dataGridView1.CellPainting += dataGridView1_CellPainting;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(13, 13, 74);
            panel3.Controls.Add(comboBox2);
            panel3.Controls.Add(comboBox1);
            panel3.Controls.Add(textBox1);
            panel3.Controls.Add(pictureBox2);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 531);
            panel3.Name = "panel3";
            panel3.Size = new Size(719, 63);
            panel3.TabIndex = 31;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.Gainsboro;
            comboBox2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(582, 17);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 29);
            comboBox2.TabIndex = 3;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.Gainsboro;
            comboBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(455, 17);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 29);
            comboBox1.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Gainsboro;
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(45, 17);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(396, 29);
            textBox1.TabIndex = 1;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(11, 13);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(35, 36);
            pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // Consulta
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(23, 24, 31);
            ClientSize = new Size(804, 594);
            Controls.Add(panel3);
            Controls.Add(menubar);
            Controls.Add(dataGridView1);
            Controls.Add(label2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Consulta";
            Text = "Consulta";
            Load += Consulta_Load;
            menubar.ResumeLayout(false);
            menubar.PerformLayout();
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label2;
        private FlowLayoutPanel menubar;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Button button1;
        private System.Windows.Forms.Timer hide_submenu;
        private DataGridView dataGridView1;
        private Panel panel1;
        private Button button2;
        private Panel panel3;
        private TextBox textBox1;
        private PictureBox pictureBox2;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
    }
}