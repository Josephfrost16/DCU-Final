﻿namespace CapaPresentacionn
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            panel1 = new Panel();
            label5 = new Label();
            nightControlBox1 = new ReaLTaiizor.Controls.NightControlBox();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            dateTimePicker1 = new DateTimePicker();
            label6 = new Label();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel9 = new Panel();
            UserTxT = new TextBox();
            label4 = new Label();
            panel8 = new Panel();
            CorTxt = new TextBox();
            label3 = new Label();
            panel7 = new Panel();
            ApeTxt = new TextBox();
            label1 = new Label();
            label2 = new Label();
            lbl = new Label();
            panel5 = new Panel();
            PasTxT2 = new MaskedTextBox();
            panel6 = new Panel();
            NomTxt = new TextBox();
            button2 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel9.SuspendLayout();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 170, 206);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(nightControlBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(337, 34);
            panel1.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(13, 9);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 2;
            label5.Text = "REGISTRARSE";
            // 
            // nightControlBox1
            // 
            nightControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            nightControlBox1.BackColor = Color.Transparent;
            nightControlBox1.CloseHoverColor = Color.FromArgb(199, 80, 80);
            nightControlBox1.CloseHoverForeColor = Color.White;
            nightControlBox1.DefaultLocation = true;
            nightControlBox1.DisableMaximizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.DisableMinimizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.EnableCloseColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMaximizeButton = true;
            nightControlBox1.EnableMaximizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMinimizeButton = true;
            nightControlBox1.EnableMinimizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.Location = new Point(198, 0);
            nightControlBox1.MaximizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MaximizeHoverForeColor = Color.White;
            nightControlBox1.MinimizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MinimizeHoverForeColor = Color.White;
            nightControlBox1.Name = "nightControlBox1";
            nightControlBox1.Size = new Size(139, 31);
            nightControlBox1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 170, 206);
            panel2.Controls.Add(panel3);
            panel2.Location = new Point(12, 23);
            panel2.Name = "panel2";
            panel2.Size = new Size(313, 471);
            panel2.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(32, 33, 36);
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(3, 7);
            panel3.Name = "panel3";
            panel3.Size = new Size(307, 459);
            panel3.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(32, 33, 36);
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Controls.Add(dateTimePicker1);
            panel4.Controls.Add(label6);
            panel4.Controls.Add(pictureBox5);
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(pictureBox3);
            panel4.Controls.Add(pictureBox2);
            panel4.Controls.Add(pictureBox1);
            panel4.Controls.Add(panel9);
            panel4.Controls.Add(label4);
            panel4.Controls.Add(panel8);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(panel7);
            panel4.Controls.Add(label1);
            panel4.Controls.Add(label2);
            panel4.Controls.Add(lbl);
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(panel6);
            panel4.Location = new Point(12, 19);
            panel4.Name = "panel4";
            panel4.Size = new Size(280, 429);
            panel4.TabIndex = 3;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Location = new Point(40, 385);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 19;
            dateTimePicker1.Value = new DateTime(2024, 4, 19, 0, 0, 0, 0);
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(73, 363);
            label6.Name = "label6";
            label6.Size = new Size(122, 15);
            label6.TabIndex = 18;
            label6.Text = "Fecha de Nacimiento:";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(21, 286);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(16, 16);
            pictureBox5.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox5.TabIndex = 17;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(20, 214);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(16, 16);
            pictureBox4.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox4.TabIndex = 16;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.email;
            pictureBox3.Location = new Point(19, 147);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(16, 16);
            pictureBox3.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox3.TabIndex = 15;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.user;
            pictureBox2.Location = new Point(20, 78);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(16, 16);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.user;
            pictureBox1.Location = new Point(19, 11);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(16, 16);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(35, 47, 62);
            panel9.Controls.Add(UserTxT);
            panel9.Location = new Point(19, 239);
            panel9.Name = "panel9";
            panel9.Size = new Size(246, 34);
            panel9.TabIndex = 11;
            // 
            // UserTxT
            // 
            UserTxT.BackColor = Color.FromArgb(35, 47, 62);
            UserTxT.BorderStyle = BorderStyle.None;
            UserTxT.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            UserTxT.ForeColor = Color.White;
            UserTxT.Location = new Point(6, 7);
            UserTxT.Name = "UserTxT";
            UserTxT.Size = new Size(235, 20);
            UserTxT.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(37, 216);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 12;
            label4.Text = "Usuario";
            label4.Click += label4_Click;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(35, 47, 62);
            panel8.Controls.Add(CorTxt);
            panel8.Location = new Point(19, 169);
            panel8.Name = "panel8";
            panel8.Size = new Size(246, 34);
            panel8.TabIndex = 9;
            // 
            // CorTxt
            // 
            CorTxt.BackColor = Color.FromArgb(35, 47, 62);
            CorTxt.BorderStyle = BorderStyle.None;
            CorTxt.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CorTxt.ForeColor = Color.White;
            CorTxt.Location = new Point(6, 7);
            CorTxt.Name = "CorTxt";
            CorTxt.Size = new Size(235, 20);
            CorTxt.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(40, 147);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 10;
            label3.Text = "Correo";
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(35, 47, 62);
            panel7.Controls.Add(ApeTxt);
            panel7.Location = new Point(20, 100);
            panel7.Name = "panel7";
            panel7.Size = new Size(246, 34);
            panel7.TabIndex = 7;
            // 
            // ApeTxt
            // 
            ApeTxt.BackColor = Color.FromArgb(35, 47, 62);
            ApeTxt.BorderStyle = BorderStyle.None;
            ApeTxt.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ApeTxt.ForeColor = Color.White;
            ApeTxt.Location = new Point(6, 7);
            ApeTxt.Name = "ApeTxt";
            ApeTxt.Size = new Size(235, 20);
            ApeTxt.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(39, 77);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 8;
            label1.Text = "Apellido";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(38, 289);
            label2.Name = "label2";
            label2.Size = new Size(66, 15);
            label2.TabIndex = 5;
            label2.Text = "Contraseña";
            // 
            // lbl
            // 
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl.ForeColor = Color.White;
            lbl.Location = new Point(38, 11);
            lbl.Name = "lbl";
            lbl.Size = new Size(51, 15);
            lbl.TabIndex = 4;
            lbl.Text = "Nombre";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(35, 47, 62);
            panel5.Controls.Add(PasTxT2);
            panel5.Location = new Point(16, 311);
            panel5.Name = "panel5";
            panel5.Size = new Size(250, 34);
            panel5.TabIndex = 3;
            // 
            // PasTxT2
            // 
            PasTxT2.BackColor = Color.FromArgb(35, 47, 62);
            PasTxT2.BorderStyle = BorderStyle.None;
            PasTxT2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            PasTxT2.ForeColor = Color.White;
            PasTxT2.Location = new Point(6, 7);
            PasTxT2.Name = "PasTxT2";
            PasTxT2.PasswordChar = '*';
            PasTxT2.Size = new Size(235, 20);
            PasTxT2.TabIndex = 0;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(35, 47, 62);
            panel6.Controls.Add(NomTxt);
            panel6.Location = new Point(19, 33);
            panel6.Name = "panel6";
            panel6.Size = new Size(246, 34);
            panel6.TabIndex = 2;
            // 
            // NomTxt
            // 
            NomTxt.BackColor = Color.FromArgb(35, 47, 62);
            NomTxt.BorderStyle = BorderStyle.None;
            NomTxt.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            NomTxt.ForeColor = Color.White;
            NomTxt.Location = new Point(6, 7);
            NomTxt.Name = "NomTxt";
            NomTxt.Size = new Size(235, 20);
            NomTxt.TabIndex = 0;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(0, 170, 206);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(79, 518);
            button2.Name = "button2";
            button2.Size = new Size(175, 36);
            button2.TabIndex = 14;
            button2.Text = "INICIAR SESION";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 33, 36);
            ClientSize = new Size(337, 582);
            Controls.Add(button2);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Register";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Register";
            Load += Register_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private ReaLTaiizor.Controls.NightControlBox nightControlBox1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel9;
        private TextBox UserTxT;
        private Label label4;
        private Panel panel8;
        private TextBox CorTxt;
        private Label label3;
        private Panel panel7;
        private TextBox ApeTxt;
        private Label label1;
        private Label label2;
        private Label lbl;
        private Panel panel5;
        private MaskedTextBox PasTxT2;
        private Panel panel6;
        private TextBox NomTxt;
        private Label label5;
        private Button button2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private DateTimePicker dateTimePicker1;
        private Label label6;
    }
}