using CapaNegocio.Usuarios;

namespace CapaPresentacionn
{

    public partial class Form1 : Form
    {
        Registro registro;
        Config config;
        Consulta consulta;
        Inicio Inicio;


        CN_Usuarios cnUsuarios = new CN_Usuarios();

        public Form1()
        {
            InitializeComponent();
            mdiProp();


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Inicio == null)
            {
                Inicio = new Inicio();
                Inicio.FormClosed += Inicio_FormClosed;
                Inicio.MdiParent = this;
                Inicio.Dock = DockStyle.Fill;
                Inicio.Show();

            }
            else
            {
                Inicio.Activate();
            }
        }

        bool menuExpand = false;
        bool menuHide = true;

        private void mdiProp()
        {
            this.SetBevel(false);
            Controls.OfType<MdiClient>().FirstOrDefault().BackColor = Color.FromArgb(232, 234, 237);

        }

        private void configTransition_Tick(object sender, EventArgs e)
        {
            if (menuExpand == false)
            {
                configContainer.Height += 10;
                if (configContainer.Height >= 125)
                {
                    configTransition.Stop();
                    menuExpand = true;

                }
            }
            else
            {
                configContainer.Height -= 10;
                if (configContainer.Height <= 43)
                {
                    configTransition.Stop();
                    menuExpand = false;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            configTransition.Start();
        }

        private void SideMenuBar_Tick(object sender, EventArgs e)
        {
            if (menuHide == false)
            {
                menubar.Width += 10;
                if (menubar.Width >= 195)
                {
                    SideMenuBar.Stop();
                    menuHide = true;

                }
            }
            else
            {
                menubar.Width -= 10;
                if (menubar.Width <= 55)
                {
                    SideMenuBar.Stop();
                    menuHide = false;
                }
            }
        }

        void pintarButton(Button a, int r, int g, int b)
        {
            a.BackColor = Color.FromArgb(r, g, b);
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            SideMenuBar.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Inicio == null)
            {
                Inicio = new Inicio();
                Inicio.FormClosed += Inicio_FormClosed;
                Inicio.MdiParent = this;
                Inicio.Dock = DockStyle.Fill;
                Inicio.Show();

            }
            else
            {
                Inicio.Activate();
            }
        }

        private void Inicio_FormClosed(object sender, FormClosedEventArgs e)
        {
            Inicio = null;
        }


        private void button1_MouseHover(object sender, EventArgs e)
        {

        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            pintarButton(button1, 23, 24, 31);
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            pintarButton(button1, 20, 20, 111);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            pintarButton(RegisterButton, 20, 20, 111);
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            pintarButton(ConsultaButton, 20, 20, 111);
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            pintarButton(configButton, 20, 20, 111);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            pintarButton(RegisterButton, 23, 24, 31);
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            pintarButton(ConsultaButton, 23, 24, 31);
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            pintarButton(configButton, 23, 24, 31);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Logincs login = new Logincs();
            login.ShowDialog();
            this.Close();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            if (registro == null)
            {
                registro = new Registro();
                registro.FormClosed += Registro_FormClosed;
                registro.MdiParent = this;
                registro.Dock = DockStyle.Fill;
                registro.Show();
            }
            else
            {
                registro.Activate();
            }
        }

        private void Registro_FormClosed(object? sender, FormClosedEventArgs e)
        {
            registro = null;
        }

        private void ConsultaButton_Click(object sender, EventArgs e)
        {
            if (consulta == null)
            {
                consulta = new Consulta();
                consulta.FormClosed += Consulta_FormClosed;
                consulta.MdiParent = this;
                consulta.Dock = DockStyle.Fill;
                consulta.Show();
            }
            else
            {
                consulta.Activate();
            }
        }

        private void Consulta_FormClosed(object? sender, FormClosedEventArgs e)
        {
            consulta = null;
        }

        private void menubar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (config == null)
            {
                config = new Config();
                config.FormClosed += Config_FormClosed;
                config.MdiParent = this;
                config.Dock = DockStyle.Fill;
                config.Show();
            }
            else
            {
                config.Activate();
            }
        }

        private void Config_FormClosed(object? sender, FormClosedEventArgs e)
        {
               config = null;
        }
    }
}

