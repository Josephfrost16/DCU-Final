﻿using CapaDatos.Usuarios;
using CapaDatos.Visitantes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.Visitantes
{
   public class CN_Visitantes
    {
        private CD_Visitantes visitantes = new CD_Visitantes();

        public DataTable MostrarVisitantes()
        {
            DataTable tabla = new DataTable();
            tabla = visitantes.Mostrar();
            return tabla;
        }

        public void InsertarVisitantes(string nombre, string apellido, int carrera, string correo, int edificio, DateTime horaEntrada, DateTime horaSalida, string motivo, byte[] foto, int aula)
        {
            visitantes.Insertar(nombre,apellido,carrera,correo,edificio,horaEntrada,horaSalida,motivo,foto,aula);
        }
    }
}
