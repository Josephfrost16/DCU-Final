﻿using CapaDatos.Aulas;
using CapaDatos.Edificios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.Aulas
{
    public class CN_Aulas
    {
        private CD_Aulas Aulas = new CD_Aulas();

        public DataTable MostrarAulas(int a)
        {
            DataTable tabla = new DataTable();
            tabla = Aulas.Mostrar(a);
            return tabla;
        }

        public DataTable MostrarAulas()
        {
            DataTable tabla = new DataTable();
            tabla = Aulas.Mostrar();
            return tabla;
        }
    }
}
