﻿using CapaDatos.Edificios;
using CapaDatos.Usuarios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CapaNegocio.Edificios
{
    public class CN_Edificios
    {
        private CD_Edificios edificios = new CD_Edificios();

        public DataTable MostrarEdificios()
        {
            DataTable tabla = new DataTable();
            tabla = edificios.Mostrar();
            return tabla;
        }

    }
}
