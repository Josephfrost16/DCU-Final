﻿using CapaDatos.Usuarios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.Usuarios
{
    public class CN_Usuarios
    {
        
       
        public DataTable MostrarUsuario()
        {
            CD_Usuarios UsuarioCD = new CD_Usuarios();
            DataTable tabla = new DataTable();
            tabla = UsuarioCD.Mostrar();
            return tabla;
        }

        public void InsertarUsuarios(string nombre, string apellido, DateTime Fecha, int tipo, string usuario, string contraseña)
        {
            CD_Usuarios UsuarioCD = new CD_Usuarios();
            UsuarioCD.Insertar(nombre, apellido, Fecha, tipo, usuario, contraseña);
        }

       

       public bool ValidarUsuario(string usuario, string contraseña)
        {
            CD_Usuarios UsuarioCD = new CD_Usuarios();
            bool validar = UsuarioCD.validarLogin(usuario, contraseña);
            return validar;
        }
    }
}
