﻿using CapaDatos.Aulas;
using CapaDatos.Carreras;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.Carreras
{
    public class CN_Carreras
    {
        private CD_Carreras Carrera = new CD_Carreras();

        public DataTable MostrarCarreras()
        {
            DataTable tabla = new DataTable();
            tabla = Carrera.Mostrar();
            return tabla;
        }
    }
}
         