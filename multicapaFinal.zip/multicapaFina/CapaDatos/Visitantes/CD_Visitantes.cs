﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos.Visitantes
{
    public class CD_Visitantes
    {
        private CD_Conexion conexion = new CD_Conexion();

        public DataTable Mostrar()
        {
            SqlDataReader Leer;
            DataTable tabla = new DataTable();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "Mostrar_Visitantes";
            comando.CommandType = CommandType.StoredProcedure;
            Leer = comando.ExecuteReader();
            tabla.Load(Leer);
            conexion.CerrarConexion();
            return tabla;
        }

        public void Insertar(string nombre, string apellido, int carrera, string correo, int edificio, DateTime horaEntrada, DateTime horaSalida, string motivo, byte[] foto, int aula)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "Insertar_Visitantes";
            comando.Parameters.AddWithValue("@Nombre", nombre);
            comando.Parameters.AddWithValue("@Apellido", apellido);
            comando.Parameters.AddWithValue("@Carrera", carrera);
            comando.Parameters.AddWithValue("@Correo", correo);
            comando.Parameters.AddWithValue("@EdificioVisitado", edificio);
            comando.Parameters.AddWithValue("@HoraEntrada", horaEntrada);
            comando.Parameters.AddWithValue("@HoraSalida", horaSalida);
            comando.Parameters.AddWithValue("@MotivoVisita", motivo);
            comando.Parameters.AddWithValue("@FotosVisitante", foto); 
            comando.Parameters.AddWithValue("@AulaVisitada", aula);
            comando.CommandType = CommandType.StoredProcedure;
            comando.ExecuteNonQuery();
            conexion.CerrarConexion();
        }

     
    }
}
