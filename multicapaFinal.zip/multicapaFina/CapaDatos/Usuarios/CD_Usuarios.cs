﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace CapaDatos.Usuarios
{
    public class CD_Usuarios
    {
        

        public DataTable Mostrar()
        {
            CD_Conexion conexion = new CD_Conexion();
            SqlDataReader Leer;
            DataTable tabla = new DataTable();
            SqlCommand comando = new SqlCommand();

            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "Mostrar_Usuarios";
            comando.CommandType = CommandType.StoredProcedure;
            Leer = comando.ExecuteReader();
            tabla.Load(Leer);
            conexion.CerrarConexion();
            return tabla;
        }

        public void Insertar(string nombre, string apellido, DateTime Fecha, int tipo, string usuario, string contraseña)
        {
            CD_Conexion conexion = new CD_Conexion();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "Insertar_Usuarios";
            comando.Parameters.AddWithValue("@Nombre", nombre);
            comando.Parameters.AddWithValue("@Apellido", apellido);
            comando.Parameters.AddWithValue("@FechaNacimiento", Fecha);
            comando.Parameters.AddWithValue("@TipoUsuario", tipo);
            comando.Parameters.AddWithValue("@Usuario", usuario);
            comando.Parameters.AddWithValue("@Contrasena", contraseña);
            comando.CommandType = CommandType.StoredProcedure;
            comando.ExecuteNonQuery();
            conexion.CerrarConexion();
        }


        public bool validarLogin(string username, string password)
        {
            CD_Conexion conexion = new CD_Conexion();
            string query = "SELECT * FROM Usuarios WHERE Usuario = @username AND Contraseña = @password";


            using (SqlCommand command = new SqlCommand(query, conexion.AbrirConexion()))
            {
                // Agrega los parámetros de la consulta
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);
                SqlDataReader Leer = command.ExecuteReader();

                // Verifica si hay un resultado
                if (Leer.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }

                // Cierra el lector de datos
                Leer.Close();
                conexion.CerrarConexion();


            }

        }
    }
}
